# Groundbreak
Midnight Movie Massacre repository for CMPUT 250 Fall 2021
- clone this git repository into a location you will remember. 

# General Workflow
1. Create a branch for the task you are on
2. Make sure you are branching from the development branch
4. When your task is complete, add and commit changes with descriptive message
5. Merge the development branch into your task branch
6. Test the game
7. If there are no conflicts and no issues, make a pull request to the development branch
8. Once request is approved, branch will be deleted it is optional to delete your local branch

